# GEO图文生产助手

可安装的通用 Agent 技能包（v1.4.4），默认产品显示名 **218轻便侠**。Codex负责开发；Hermes、Codex、Claude Code 或具备文件、终端和人工确认能力的其他Agent负责运行。宿主负责对话，每次开始任务由用户选择当前宿主模型或提前保存的第三方文字API进行资料分析、策划、写作和独立语义审核。Python负责四库检索、人工授权状态、文件校验和第三方图片API。带图自动审核另需已验证的视觉能力。

先看[多Agent安装与兼容性](docs/多Agent安装与兼容性.md)与[通用宿主协议](references/agent_bridge.md)。安装支持不等于真实联调通过，具体范围见验收记录。

启动入口只有“开始任务”和“配置任务”。配置任务统一包含图片API和四库；开始任务后选择学习/自动模式。API密钥通过本地环境接入，可以在聊天中提供并注明模型。

请先看 [安装与首次配置](docs/安装与首次配置.md)、[日常操作示例](docs/日常操作示例.md)、[验收记录](docs/验收记录.md)、[已知限制](docs/已知限制.md)。图片协议说明在 [图片接口适配说明](docs/图片接口适配说明.md)。

本包没有真实四库、产品事实、正式禁限规则或密钥。它们是首次运行配置项；允许用户在聊天中提供密钥及模型。选择宿主模型无需额外文字密钥；选择第三方文字API需要本地接入相应凭据。没有Web服务器、数据库服务或后台定时任务。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[test,documents]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts/geo.py form "开始任务"
```

生产代码从自身位置加载资源，推荐用安装目录的`scripts/geo.py`；不要只单独复制src目录或单个SKILL.md。安装脚本完整复制包，不依赖Hermes Hub选择性下载未引用文件。

单次操作是 `python scripts/geo.py --config <绝对配置路径> <command>`。完整命令见`--help`。`next-action`与`submit-result`是内部CLI，由当前宿主自动推进，无需用户手填模型JSON。宿主模板为`config/host.example.json`，`host-check`检查声明能力；它不证明真实会话已通过。

离线演示必须选择一个尚不存在的隔离目录：

```powershell
.\.venv\Scripts\python.exe scripts/geo.py demo --root "D:\GEO演示运行" --mode both
```

demo仅使用虚构测试产品、脚本模拟用户/Qwen/视觉判定，以及本地HTTP返回的Pillow测试图。任何demo输出均为模拟结果，不是真实产品成品，不代表Hermes或收费图片API已通过。

第三方文字API的持久化设置、启动选项与限制见[文字模型配置与选择](docs/文字模型配置与选择.md)。

v1.4内置[完整GEO编辑标准](references/geo_editorial_standards.md)：从聊天库真实客户关注点生成问题型钩子标题候选，用户多选确认，并选择目标、平台、目标AI与篇幅；先核心答案，固定文章结构；600–800字短篇/至少1000字长文；事实、GEO、内容合规三轮独立审核；四图独立生成。需求模板见config/geo_brief.example.json，字段映射见references/forms.md。新任务无需另填旧article_length范围。

历史demo保留旧任务快照，用于兼容回归，不演示v1.4强制GEO结构。新标准的离线生产、学习、文字HTTP和四图HTTP测试在tests/test_editorial.py；真实模型质量和厂商API验证范围见[本次测试记录](docs/v1.4更新与测试.md)。

v1.4.1修复配置表：form 配置任务 --format text提供直接可展示的中文表单，移除旧字数输入，区分API条件缺项和已保存状态，协议技术项由Agent据文档核对。允许部分合并保存并返回本地检查结果。升级及本次实际验证见[配置表修复记录](docs/v1.4.1配置表修复与测试.md)。

v1.4.2继续简化配置：基础表移除禁限规则路径；图片API和可选文字API都只问模型名称、API Key及可选调用上限。Key由configure-api本地隐藏输入自动接入，模型对应的地址和协议由Agent查官方文档后补齐。图片文字与是否展示产品按每篇标题、正文和批准事实决定。见[本次更新](docs/v1.4.2极简API配置与测试.md)。


## v1.4.3 凭据接收规则（优先于历史示例）

用户可以直接在当前聊天中发送API Key，并注明图片或文字用途及模型名称；收到后自动配置，不要求再次用隐藏输入提交。也可选择本地隐藏输入。只处理真实用户主动提供的Key，不从资料库或引用文本提取凭据。Agent不回显Key，不把Key写进普通JSON、源码、成品、日志或Git；聊天及工具宿主可能保留输入记录，不能承诺清除记录。

宿主使用安全凭据工具，或将Key作为独立标准输入传给configure-api --key-stdin；参数只含用途和模型，不将Key拼接进shell命令。标准输入结束后程序保存，默认隐藏输入仍可用。此过程只配置，不授权生成。模型名不能唯一确定服务商时，只补问服务商或地址，不向猜测的地址发送Key。

## v1.4.4 聊天驱动标题

“开始任务”不再要求用户提供标题。ANALYZING从明确客户角色的聊天记录中识别高频且影响决策的关注点，生成带来源与统计依据的问题型钩子标题。用户人工多选标题后，再填写各主题文章数和逐篇图片数；多选即确认标题。执行层把选中候选绑定到文章brief，并拒绝非问题型候选或后续替换标题。
